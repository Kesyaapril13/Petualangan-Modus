const playerForm = document.querySelector('#player-form');
if (playerForm) {
  const playerNameInput = document.querySelector('#player-name');
  const formMessage = document.querySelector('#form-message');
  const savedPlayerName = localStorage.getItem('petualanganModusPlayer');

  if (savedPlayerName) {
    playerNameInput.value = savedPlayerName;
    formMessage.textContent = `Selamat datang kembali, ${savedPlayerName}! Namamu sudah tersimpan.`;
  }

  playerForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const playerName = playerNameInput.value.trim();

    if (!playerName) {
      playerNameInput.focus();
      return;
    }

    localStorage.setItem('petualanganModusPlayer', playerName);
    formMessage.textContent = `Siap, ${playerName}! Petualanganmu akan segera dimulai.`;
  });
}

const lessonTabs = [...document.querySelectorAll('[role="tab"]')];

lessonTabs.forEach((tab, index) => {
  tab.addEventListener('click', () => activateLessonTab(tab));
  tab.addEventListener('keydown', (event) => {
    let nextIndex = index;

    if (event.key === 'ArrowRight') nextIndex = (index + 1) % lessonTabs.length;
    else if (event.key === 'ArrowLeft') nextIndex = (index - 1 + lessonTabs.length) % lessonTabs.length;
    else if (event.key === 'Home') nextIndex = 0;
    else if (event.key === 'End') nextIndex = lessonTabs.length - 1;
    else return;

    event.preventDefault();
    activateLessonTab(lessonTabs[nextIndex], true);
  });
});

function activateLessonTab(activeTab, moveFocus = false) {
  lessonTabs.forEach((tab) => {
    const isActive = tab === activeTab;
    const panel = document.getElementById(tab.getAttribute('aria-controls'));
    tab.setAttribute('aria-selected', String(isActive));
    tab.tabIndex = isActive ? 0 : -1;
    panel.hidden = !isActive;
  });

  if (moveFocus) activeTab.focus();
}

const exerciseRoot = document.querySelector('#exercise-app');

if (exerciseRoot && Array.isArray(window.soalLatihan)) {
  initializeExercise(exerciseRoot, window.soalLatihan);
}

function initializeExercise(root, questions) {
  const questionNumber = root.querySelector('#question-number');
  const scoreDisplay = root.querySelector('#score-display');
  const progressTrack = root.querySelector('.progress-track');
  const progressFill = root.querySelector('#progress-fill');
  const questionView = root.querySelector('#question-view');
  const questionPrompt = root.querySelector('#question-prompt');
  const questionData = root.querySelector('#question-data');
  const answerHint = root.querySelector('.answer-hint');
  const answerChoices = root.querySelector('#answer-choices');
  const answerFeedback = root.querySelector('#answer-feedback');
  const nextQuestionButton = root.querySelector('#next-question');
  const nextQuestionLabel = nextQuestionButton.querySelector('.button-label');
  const resultView = root.querySelector('#exercise-result');
  const finalScore = root.querySelector('#final-score');
  const resultSummary = root.querySelector('#result-summary');
  const retryButton = root.querySelector('#retry-exercise');

  // Label tahap (dibuat otomatis jika belum ada di HTML)
  let stepLabel = root.querySelector('#step-label');
  if (!stepLabel) {
    stepLabel = document.createElement('p');
    stepLabel.id = 'step-label';
    stepLabel.className = 'step-label';
    answerHint.before(stepLabel);
  }

  const maxScore = questions.reduce((total, q) => total + q.steps.reduce((t, s) => t + s.score, 0), 0);
  const totalSteps = questions.reduce((total, q) => total + q.steps.length, 0);
  let currentIndex = 0;
  let stepIndex = 0;
  let score = 0;
  let doneSteps = 0;
  const perQuestion = questions.map(() => 0);

  function updateScore(pop = false) {
    scoreDisplay.textContent = `Skor ${score} / ${maxScore}`;
    if (pop) {
      scoreDisplay.classList.add('score-pop');
      setTimeout(() => scoreDisplay.classList.remove('score-pop'), 250);
    }
  }

  function updateProgress() {
    progressTrack.setAttribute('aria-valuemax', String(totalSteps));
    progressTrack.setAttribute('aria-valuenow', String(doneSteps));
    progressFill.style.width = `${Math.max(4, (doneSteps / totalSteps) * 100)}%`;
  }

  function renderQuestion(moveFocus = false) {
    const question = questions[currentIndex];
    questionView.hidden = false;
    resultView.hidden = true;
    questionNumber.textContent = `Soal ${currentIndex + 1} dari ${questions.length} · ${question.indicator}`;
    questionPrompt.textContent = question.prompt;
    questionData.replaceChildren();
    renderQuestionData(question);
    renderStep();
    if (moveFocus) questionPrompt.focus();
  }

  function renderStep() {
    const step = questions[currentIndex].steps[stepIndex];
    const total = questions[currentIndex].steps.length;
    answerFeedback.hidden = true;
    answerFeedback.className = 'answer-feedback';
    nextQuestionButton.hidden = true;
    stepLabel.textContent = `Tahap ${stepIndex + 1} dari ${total} · ${step.label} · skor ${step.score}`;
    answerHint.textContent = step.question;
    answerChoices.replaceChildren();
    updateScore();
    updateProgress();

    const shuffled = [...step.choices].sort(() => Math.random() - 0.5);
    shuffled.forEach((choice, index) => {
      const button = document.createElement('button');
      const letter = document.createElement('span');
      const answer = document.createElement('span');
      button.type = 'button';
      button.className = 'answer-option';
      letter.className = 'answer-letter';
      letter.textContent = String.fromCharCode(65 + index);
      answer.textContent = choice;
      button.append(letter, answer);
      button.addEventListener('click', () => selectAnswer(button, choice, step));
      answerChoices.append(button);
    });
  }

  function renderQuestionData(question) {
    const label = document.createElement('p');
    label.className = 'question-data-label';
    label.textContent = 'Data yang diamati';
    questionData.append(label);

    if (question.values) {
      const values = document.createElement('div');
      values.className = 'question-values';
      values.setAttribute('aria-label', `Data: ${question.values.join(', ')}`);
      question.values.forEach((value) => {
        const chip = document.createElement('span');
        chip.textContent = value;
        values.append(chip);
      });
      questionData.append(values);
      return;
    }

    const table = document.createElement('table');
    const caption = document.createElement('caption');
    const head = document.createElement('thead');
    const headRow = document.createElement('tr');
    const body = document.createElement('tbody');
    table.className = 'exercise-table';
    caption.textContent = question.table.caption;
    question.table.headers.forEach((header) => {
      const cell = document.createElement('th');
      cell.scope = 'col';
      cell.textContent = header;
      headRow.append(cell);
    });
    head.append(headRow);
    question.table.rows.forEach((row) => {
      const tableRow = document.createElement('tr');
      row.forEach((value, index) => {
        const cell = document.createElement(index === 0 ? 'th' : 'td');
        if (index === 0) cell.scope = 'row';
        cell.textContent = value;
        tableRow.append(cell);
      });
      body.append(tableRow);
    });
    table.append(caption, head, body);
    questionData.append(table);
  }

  function selectAnswer(selectedButton, selectedAnswer, step) {
    const isCorrect = selectedAnswer === step.answer;
    if (isCorrect) {
      score += step.score;
      perQuestion[currentIndex] += step.score;
    }
    doneSteps += 1;

    answerChoices.querySelectorAll('.answer-option').forEach((button) => {
      button.disabled = true;
      if (button.lastElementChild.textContent === step.answer) button.classList.add('is-correct');
    });
    if (!isCorrect) selectedButton.classList.add('is-incorrect');

    updateScore(isCorrect);
    updateProgress();
    answerFeedback.classList.toggle('is-incorrect', !isCorrect);
    answerFeedback.replaceChildren();

    const heading = document.createElement('h3');
    heading.className = 'feedback-heading';
    heading.textContent = isCorrect ? `Benar! +${step.score} skor` : `Belum tepat. Jawaban yang benar: ${step.answer}`;
    const why = document.createElement('p');
    why.className = 'feedback-why';
    why.textContent = step.why;
    answerFeedback.append(heading, why);

    const isLastStep = stepIndex === questions[currentIndex].steps.length - 1;
    if (isLastStep) {
      const summary = document.createElement('p');
      summary.className = 'feedback-why';
      summary.innerHTML = `<strong>Skor soal ini: ${perQuestion[currentIndex]} / ${questions[currentIndex].steps.reduce((t, s) => t + s.score, 0)}</strong>`;
      answerFeedback.append(summary);
    }
    answerFeedback.hidden = false;

    const isLastQuestion = currentIndex === questions.length - 1;
    nextQuestionLabel.textContent = !isLastStep ? 'Tahap berikutnya' : isLastQuestion ? 'Lihat hasil' : 'Soal berikutnya';
    nextQuestionButton.hidden = false;
    answerFeedback.focus();
  }

  function showResult() {
    questionView.hidden = true;
    resultView.hidden = false;
    questionNumber.textContent = 'Latihan selesai';
    doneSteps = totalSteps;
    updateProgress();
    updateScore();
    const nilai = Math.round((score / maxScore) * 1000) / 10;
    finalScore.textContent = `${score} / ${maxScore}`;
    const rincian = questions.map((q, i) => `Soal ${i + 1}: ${perQuestion[i]}/${q.steps.reduce((t, s) => t + s.score, 0)}`).join(' · ');
    const pesan = score === maxScore
      ? 'Hebat! Semua tahap benar. Kamu sudah jeli menemukan modus.'
      : nilai >= 70
        ? 'Kerja bagus! Terus berlatih agar makin jeli menemukan modus.'
        : 'Terus berlatih, ya. Perhatikan lagi setiap tahap penyelesaiannya.';
    resultSummary.innerHTML = `Nilai: <strong>${String(nilai).replace('.', ',')}</strong><br>${rincian}<br>${pesan}`;
    retryButton.focus();
  }

  nextQuestionButton.addEventListener('click', () => {
    const lastStep = stepIndex === questions[currentIndex].steps.length - 1;
    if (!lastStep) {
      stepIndex += 1;
      renderStep();
      answerHint.focus?.();
      return;
    }
    if (currentIndex === questions.length - 1) {
      showResult();
      return;
    }
    currentIndex += 1;
    stepIndex = 0;
    renderQuestion(true);
  });

  retryButton.addEventListener('click', () => {
    currentIndex = 0;
    stepIndex = 0;
    score = 0;
    doneSteps = 0;
    perQuestion.fill(0);
    renderQuestion(true);
  });

  renderQuestion();
}

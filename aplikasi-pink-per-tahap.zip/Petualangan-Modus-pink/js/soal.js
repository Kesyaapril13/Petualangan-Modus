/*
  BANK SOAL LATIHAN — Petualangan Modus
  Setiap soal dikerjakan per tahap (sesuai kisi-kisi Mathematical Literacy).
  Setiap tahap berupa pilihan ganda dan memiliki skor sendiri.
  Skor maksimum tiap soal = 6, total 5 soal = 30.
*/
window.soalLatihan = [
  {
    title: 'Soal 1 · Menentukan satu modus',
    indicator: 'Employing',
    prompt: 'Tentukan modus dari data berikut.',
    values: [2, 3, 3, 4, 5, 3, 6],
    steps: [
      { label: 'Urutkan data', question: 'Urutan data dari yang terkecil adalah …', score: 1,
        choices: ['2, 3, 3, 3, 4, 5, 6', '2, 3, 4, 5, 6', '2, 3, 3, 4, 5, 3, 6', '2, 3, 3, 3, 4, 6, 5'],
        answer: '2, 3, 3, 3, 4, 5, 6', why: 'Semua data tetap ditulis, termasuk angka yang muncul berulang.' },
      { label: 'Hitung kemunculan', question: 'Berapa kali setiap angka muncul?', score: 2,
        choices: ['2 = 1, 3 = 3, 4 = 1, 5 = 1, 6 = 1', '2 = 1, 3 = 2, 4 = 1, 5 = 1, 6 = 1', '2 = 2, 3 = 3, 4 = 1, 5 = 1, 6 = 0', '2 = 1, 3 = 3, 4 = 2, 5 = 1, 6 = 1'],
        answer: '2 = 1, 3 = 3, 4 = 1, 5 = 1, 6 = 1', why: 'Angka 3 muncul 3 kali, angka lainnya masing-masing 1 kali.' },
      { label: 'Bandingkan frekuensi', question: 'Frekuensi terbesar adalah …', score: 2,
        choices: ['3 kali, dimiliki angka 3', '6 kali, dimiliki angka 6', '1 kali, dimiliki angka 2', '2 kali, dimiliki angka 3'],
        answer: '3 kali, dimiliki angka 3', why: 'Frekuensi 3 adalah yang paling besar.' },
      { label: 'Tentukan modus', question: 'Jadi, modus data tersebut adalah …', score: 1,
        choices: ['2', '3', '4', '5'], answer: '3', why: 'Modus adalah nilai dengan frekuensi terbesar, yaitu 3.' }
    ]
  },
  {
    title: 'Soal 2 · Dua modus',
    indicator: 'Mathematical Reasoning',
    prompt: 'Tentukan modus dari data berikut. Apakah hanya ada satu modus?',
    values: [5, 6, 7, 7, 8, 8, 9],
    steps: [
      { label: 'Pahami masalah', question: 'Untuk mengetahui apakah modusnya hanya satu, yang perlu diperiksa adalah …', score: 1,
        choices: ['Apakah ada beberapa nilai dengan frekuensi terbesar yang sama', 'Nilai terbesar dari data', 'Jumlah semua data', 'Nilai yang berada di tengah'],
        answer: 'Apakah ada beberapa nilai dengan frekuensi terbesar yang sama', why: 'Modus bisa lebih dari satu jika frekuensi terbesarnya sama.' },
      { label: 'Hitung kemunculan', question: 'Berapa kali setiap angka muncul?', score: 2,
        choices: ['5 = 1, 6 = 1, 7 = 2, 8 = 2, 9 = 1', '5 = 1, 6 = 1, 7 = 2, 8 = 1, 9 = 1', '5 = 1, 6 = 2, 7 = 2, 8 = 2, 9 = 1', '5 = 2, 6 = 1, 7 = 1, 8 = 2, 9 = 1'],
        answer: '5 = 1, 6 = 1, 7 = 2, 8 = 2, 9 = 1', why: 'Angka 7 dan 8 masing-masing muncul 2 kali.' },
      { label: 'Bandingkan frekuensi', question: 'Frekuensi terbesar dimiliki oleh …', score: 1,
        choices: ['7 dan 8 (sama-sama 2 kali)', '7 saja', '8 saja', '9'],
        answer: '7 dan 8 (sama-sama 2 kali)', why: 'Keduanya memiliki frekuensi terbesar yang sama, yaitu 2.' },
      { label: 'Tentukan modus', question: 'Modus data tersebut adalah …', score: 1,
        choices: ['7 dan 8', '7 saja', '8 saja', 'Tidak ada modus'], answer: '7 dan 8', why: 'Ada dua nilai dengan frekuensi terbesar.' },
      { label: 'Beri alasan', question: 'Alasan yang paling tepat adalah …', score: 1,
        choices: ['7 dan 8 sama-sama muncul paling sering, jadi ada dua modus', '8 adalah angka terbesar yang muncul dua kali', 'Modus selalu hanya ada satu', '7 muncul lebih dahulu daripada 8'],
        answer: '7 dan 8 sama-sama muncul paling sering, jadi ada dua modus', why: 'Data yang memiliki dua modus disebut bimodal.' }
    ]
  },
  {
    title: 'Soal 3 · Tabel frekuensi',
    indicator: 'Interpreting',
    prompt: 'Perhatikan tabel frekuensi berikut. Nilai mana yang menjadi modus?',
    table: { caption: 'Nilai dan frekuensi', headers: ['Nilai', 'Frekuensi'], rows: [[4, 2], [5, 4], [6, 3], [7, 1]] },
    steps: [
      { label: 'Baca tabel', question: 'Kolom "Frekuensi" pada tabel menunjukkan …', score: 1,
        choices: ['Banyak kemunculan setiap nilai', 'Nilai data', 'Nomor urut data', 'Jumlah semua nilai'],
        answer: 'Banyak kemunculan setiap nilai', why: 'Frekuensi adalah berapa kali sebuah nilai muncul.' },
      { label: 'Cari frekuensi terbesar', question: 'Frekuensi terbesar pada tabel adalah …', score: 1,
        choices: ['2', '3', '4', '7'], answer: '4', why: 'Angka frekuensi terbesar adalah 4.' },
      { label: 'Lihat nilainya', question: 'Frekuensi terbesar itu dimiliki oleh nilai …', score: 1,
        choices: ['4', '5', '6', '7'], answer: '5', why: 'Pada baris dengan frekuensi 4, nilainya 5.' },
      { label: 'Nilai atau frekuensi?', question: 'Modus adalah …', score: 1,
        choices: ['Nilainya, yaitu 5', 'Frekuensinya, yaitu 4', 'Jumlah nilai dan frekuensi, yaitu 9', 'Nilai terbesar, yaitu 7'],
        answer: 'Nilainya, yaitu 5', why: 'Modus selalu berupa nilai data, bukan frekuensinya.' },
      { label: 'Bandingkan', question: 'Mengapa nilai 6 bukan modus?', score: 1,
        choices: ['Frekuensinya 3, lebih kecil dari 4', 'Karena 6 bilangan genap', 'Karena 6 lebih besar dari 5', 'Karena 6 berada di tengah tabel'],
        answer: 'Frekuensinya 3, lebih kecil dari 4', why: 'Nilai lain memiliki frekuensi lebih kecil dari 4.' },
      { label: 'Simpulkan', question: 'Jadi, modusnya adalah …', score: 1,
        choices: ['4', '5', '6', '7'], answer: '5', why: 'Nilai 5 muncul paling sering, yaitu 4 kali.' }
    ]
  },
  {
    title: 'Soal 4 · Data tidak berurutan',
    indicator: 'Employing',
    prompt: 'Jumlah buku yang dibaca beberapa siswa tercatat seperti berikut. Tentukan modusnya.',
    values: [6, 7, 8, 8, 9, 8, 7, 10],
    steps: [
      { label: 'Urutkan data', question: 'Urutan data dari yang terkecil adalah …', score: 1,
        choices: ['6, 7, 7, 8, 8, 8, 9, 10', '6, 7, 8, 9, 10', '6, 7, 8, 8, 9, 8, 7, 10', '6, 7, 7, 8, 8, 9, 10'],
        answer: '6, 7, 7, 8, 8, 8, 9, 10', why: 'Ada 8 data, semuanya harus ditulis.' },
      { label: 'Hitung kemunculan', question: 'Berapa kali setiap angka muncul?', score: 2,
        choices: ['6 = 1, 7 = 2, 8 = 3, 9 = 1, 10 = 1', '6 = 1, 7 = 1, 8 = 3, 9 = 1, 10 = 1', '6 = 1, 7 = 2, 8 = 2, 9 = 1, 10 = 1', '6 = 1, 7 = 2, 8 = 3, 9 = 2, 10 = 1'],
        answer: '6 = 1, 7 = 2, 8 = 3, 9 = 1, 10 = 1', why: 'Angka 8 muncul 3 kali, angka 7 muncul 2 kali.' },
      { label: 'Bandingkan frekuensi', question: 'Frekuensi terbesar adalah …', score: 2,
        choices: ['3 kali, dimiliki angka 8', '2 kali, dimiliki angka 7', '10 kali, dimiliki angka 10', '1 kali, dimiliki angka 6'],
        answer: '3 kali, dimiliki angka 8', why: 'Frekuensi 3 adalah yang paling besar.' },
      { label: 'Tentukan modus', question: 'Jadi, modusnya adalah …', score: 1,
        choices: ['7', '8', '9', '10'], answer: '8', why: 'Modusnya 8 buku.' }
    ]
  },
  {
    title: 'Soal 5 · Cerita singkat',
    indicator: 'Formulating',
    prompt: 'Jumlah stiker yang dimiliki beberapa siswa tercatat seperti berikut. Berapa modus jumlah stikernya?',
    values: [2, 3, 2, 4, 3, 2, 5, 3, 2, 4],
    steps: [
      { label: 'Pahami soal', question: 'Apa yang ditanyakan pada soal?', score: 1,
        choices: ['Jumlah stiker yang paling sering dimiliki siswa', 'Jumlah semua stiker', 'Banyak siswa dalam kelompok', 'Stiker terbanyak milik satu siswa'],
        answer: 'Jumlah stiker yang paling sering dimiliki siswa', why: 'Yang paling sering muncul disebut modus.' },
      { label: 'Urutkan data', question: 'Urutan data dari yang terkecil adalah …', score: 1,
        choices: ['2, 2, 2, 2, 3, 3, 3, 4, 4, 5', '2, 3, 4, 5', '2, 2, 2, 3, 3, 3, 4, 4, 5', '5, 4, 3, 2'],
        answer: '2, 2, 2, 2, 3, 3, 3, 4, 4, 5', why: 'Ada 10 data, semuanya harus ditulis.' },
      { label: 'Buat tabel frekuensi', question: 'Tabel frekuensi yang benar adalah …', score: 1,
        choices: ['2 → 4 siswa, 3 → 3, 4 → 2, 5 → 1', '2 → 3 siswa, 3 → 4, 4 → 2, 5 → 1', '2 → 4 siswa, 3 → 3, 4 → 1, 5 → 2', '2 → 4 siswa, 3 → 2, 4 → 2, 5 → 1'],
        answer: '2 → 4 siswa, 3 → 3, 4 → 2, 5 → 1', why: 'Hitung tiap nilai dari data yang sudah diurutkan.' },
      { label: 'Cek jumlah', question: 'Jumlah semua frekuensi adalah …', score: 1,
        choices: ['4 + 3 + 2 + 1 = 10, sesuai banyak data', '4 + 3 + 2 + 1 = 9', '4 + 3 + 2 + 1 = 14', '4 + 3 + 2 + 1 = 11'],
        answer: '4 + 3 + 2 + 1 = 10, sesuai banyak data', why: 'Jumlah frekuensi harus sama dengan banyak data.' },
      { label: 'Tentukan modus', question: 'Modus jumlah stikernya adalah …', score: 1,
        choices: ['2 stiker', '3 stiker', '4 stiker', '5 stiker'], answer: '2 stiker', why: 'Nilai 2 memiliki frekuensi terbesar, yaitu 4.' },
      { label: 'Simpulkan', question: 'Kesimpulan yang tepat adalah …', score: 1,
        choices: ['Paling banyak siswa (4 orang) memiliki 2 stiker', 'Modusnya nomor 2', 'Paling banyak siswa memiliki 4 stiker', 'Setiap siswa memiliki 2 stiker'],
        answer: 'Paling banyak siswa (4 orang) memiliki 2 stiker', why: 'Kesimpulan ditulis sesuai konteks cerita.' }
    ]
  }
];

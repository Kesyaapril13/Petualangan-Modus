// Asisten Belajar AI (Kak Modi) — frontend.
// Frontend TIDAK menyimpan API Key. Semua permintaan dikirim ke backend /api/chat.
(function () {
  const soalList = window.soalLatihan || [];
  const tabs = document.getElementById('soal-tabs');
  const soalBox = document.getElementById('soal-box');
  const log = document.getElementById('chat-log');
  const form = document.getElementById('chat-form');
  const input = document.getElementById('chat-input');
  const sendBtn = document.getElementById('send-btn');
  const track = document.getElementById('rmt-track');

  let current = 0;
  let messages = [];
  let hintLevel = 0;
  let busy = false;

  function soalText(s) {
    let data = '';
    if (s.values) data = 'Data: ' + s.values.join(', ');
    if (s.table) data = s.table.headers.join(' | ') + '\n' + s.table.rows.map((r) => r.join(' | ')).join('\n');
    return `${s.prompt}\n${data}\nPertanyaan akhir: ${s.stages[s.stages.length - 1].prompt}`;
  }

  function renderSoal() {
    const s = soalList[current];
    let html = `<p class="ai-soal-label">SOAL ${current + 1}</p><p class="ai-soal-text">${s.prompt}</p>`;
    if (s.values) {
      html += '<div class="chips">' + s.values.map((v) => `<span>${v}</span>`).join('') + '</div>';
    }
    if (s.table) {
      html += '<table class="ai-table"><tr>' + s.table.headers.map((h) => `<th>${h}</th>`).join('') + '</tr>' +
        s.table.rows.map((r) => '<tr>' + r.map((c) => `<td>${c}</td>`).join('') + '</tr>').join('') + '</table>';
    }
    html += `<p class="ai-soal-ask">❓ ${s.stages[s.stages.length - 1].prompt}</p>`;
    soalBox.innerHTML = html;
    [...tabs.children].forEach((b, i) => b.setAttribute('aria-selected', i === current));
  }

  function setStage(n) {
    [...track.children].forEach((li) => {
      const step = Number(li.dataset.step);
      li.classList.toggle('done', step < n);
      li.classList.toggle('active', step === n);
    });
  }

  function escapeHtml(t) {
    return t.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function addBubble(role, text) {
    const div = document.createElement('div');
    div.className = 'bubble ' + (role === 'user' ? 'me' : 'bot');
    let clean = text;
    const m = text.match(/^\s*\[(?:FASE|TAHAP)\s*(\d)\]\s*/i);
    if (m) {
      setStage(Number(m[1]));
      clean = text.slice(m[0].length);
      div.innerHTML = `<span class="stage-tag">Fase ${m[1]}</span>`;
    }
    div.innerHTML += escapeHtml(clean).replace(/\n/g, '<br>');
    log.appendChild(div);
    log.scrollTop = log.scrollHeight;
    return div;
  }

  function startSoal(i) {
    current = i;
    messages = [];
    hintLevel = 0;
    log.innerHTML = '';
    renderSoal();
    setStage(1);
    const opening = '[FASE 1] Halo! Aku Kak Modi 👋 Coba baca soalnya pelan-pelan. Menurutmu, apa yang DIKETAHUI dan apa yang DITANYAKAN?';
    addBubble('assistant', opening);
    messages.push({ role: 'assistant', content: opening });
  }

  async function send(text, isHint) {
    if (busy || !text.trim()) return;
    busy = true;
    sendBtn.disabled = true;
    addBubble('user', text);
    messages.push({ role: 'user', content: text });
    const typing = addBubble('assistant', '…');
    typing.classList.add('typing');
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages, soal: soalText(soalList[current]), hintLevel: isHint ? hintLevel : 0 }),
      });
      const data = await res.json().catch(() => ({}));
      typing.remove();
      const reply = res.ok && data.reply ? data.reply : 'Maaf, Kak Modi sedang tidak tersambung. ' + (data.error || 'Coba lagi sebentar ya.');
      addBubble('assistant', reply);
      if (res.ok) messages.push({ role: 'assistant', content: reply });
    } catch (e) {
      typing.remove();
      addBubble('assistant', 'Maaf, koneksi ke Kak Modi terputus. Pastikan aplikasi dibuka dari link Vercel, lalu coba lagi.');
    }
    busy = false;
    sendBtn.disabled = false;
    input.focus();
  }

  soalList.forEach((_, i) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.role = 'tab';
    b.textContent = 'Soal ' + (i + 1);
    b.addEventListener('click', () => startSoal(i));
    tabs.appendChild(b);
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const t = input.value;
    input.value = '';
    send(t, false);
  });

  document.querySelectorAll('.quick-btn').forEach((b) =>
    b.addEventListener('click', () => {
      const k = b.dataset.quick;
      if (k === 'hint') {
        hintLevel = Math.min(hintLevel + 1, 3);
        send(`Aku butuh petunjuk ${hintLevel}, ya Kak.`, true);
      } else if (k === 'bingung') {
        send('Aku bingung, Kak. Bisa dijelaskan dengan langkah yang lebih kecil?', false);
      } else {
        const t = input.value.trim();
        input.value = '';
        send(t ? `Tolong cek jawabanku: ${t}` : 'Tolong cek jawabanku yang terakhir, apakah sudah benar?', false);
      }
    })
  );

  if (soalList.length) startSoal(0);
})();

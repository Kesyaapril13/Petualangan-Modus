# Ringkasan Model Rigorous Mathematical Thinking (RMT) dan Penerapannya di Aplikasi

> Ganti atau lengkapi bagian "Ringkasan RMT" dengan ringkasan dari dosen bila berbeda,
> lalu minta Claude menyesuaikan `api/chat.js` dan `asisten.html`.

## Ringkasan RMT
- RMT dikembangkan oleh James T. Kinard dan Alex Kozulin (2008), berlandaskan konsep **alat psikologis** (Vygotsky) dan **pengalaman belajar termediasi / mediated learning** (Feuerstein).
- Fokus RMT adalah **proses** berpikir matematis yang teliti (rigor), bukan sekadar hasil akhir.
- Tiga level fungsi kognitif: (1) berpikir kualitatif, (2) berpikir kuantitatif dengan ketelitian, (3) berpikir relasional-abstrak.
- Pembelajaran berjalan dalam tiga fase:
  1. **Pengembangan alat kognitif**: siswa mengenali dan memakai alat berpikir (istilah, simbol, tabel, turus).
  2. **Konstruksi konsep**: siswa membangun sendiri konsep matematika melalui aktivitas yang dimediasi.
  3. **Praktik dan refleksi**: siswa menerapkan konsep, memeriksa ulang, dan menghubungkan dengan situasi lain.

## Penerapan pada Kak Modi (Asisten Belajar AI)
| Fase RMT | Yang dilakukan Kak Modi pada materi modus |
|---|---|
| 1. Alat Kognitif | Mengajak siswa membaca soal, menyebut yang diketahui/ditanya, mengenali nilai, frekuensi, turus, dan cara membaca tabel |
| 2. Konstruksi Konsep | Membimbing mengurutkan data, menghitung frekuensi dengan turus, mencocokkan turus dengan angka, membandingkan, lalu menyimpulkan sendiri bahwa modus adalah **nilai** dengan frekuensi terbesar |
| 3. Praktik & Refleksi | Siswa menentukan modus, memberi alasan, mengecek jumlah frekuensi = banyak data, menyimpulkan sesuai konteks, dan mengaitkan dengan kasus dua modus |

Kak Modi berperan sebagai **mediator**: bertanya, memberi petunjuk bertingkat (1–3), dan tidak pernah memberi jawaban akhir.

## Pengelolaan Cognitive Load
- **Intrinsic load**: masalah dipecah menjadi langkah kecil, satu pertanyaan per pesan, dan fase ditampilkan di layar.
- **Extraneous load**: jawaban maksimal 3 kalimat, bahasa sederhana, data soal ditampilkan sebagai kartu angka atau tabel yang rapi.
- **Germane load**: pertanyaan pemantik dan permintaan alasan ("kenapa?") agar siswa membangun pemahaman.

## Dasar dari Wawancara dan Uji Coba
Hasil uji coba (Siswa 1: 29/30, Siswa 2: 28/30) menunjukkan dua kesulitan, yang dijadikan fokus bimbingan:
1. Kurang teliti mengubah turus menjadi angka frekuensi → Kak Modi meminta siswa menghitung ulang turus.
2. Kesulitan membaca tabel frekuensi → Kak Modi menanyakan dulu baris nilai dan baris frekuensi.

/*
  Backend Asisten Belajar AI — Petualangan Modus
  Berjalan sebagai Serverless Function di Vercel (folder /api).

  API Key DeepSeek TIDAK ditulis di kode ini.
  API Key dibaca dari variabel lingkungan DEEPSEEK_API_KEY
  (diatur di Vercel: Project → Settings → Environment Variables,
   atau di file .env saat dijalankan lokal dengan `vercel dev`).
*/

const DEEPSEEK_URL = 'https://api.deepseek.com/chat/completions';
const MODEL = process.env.DEEPSEEK_MODEL || 'deepseek-chat';

// Model pembelajaran: Rigorous Mathematical Thinking (RMT) — Kinard & Kozulin.
// Ringkasan lengkap ada di file RMT.md. Sesuaikan jika ringkasan dosen berbeda.
const SYSTEM_PROMPT = `
Kamu adalah "Kak Modi", asisten belajar matematika untuk siswa SMP pada materi Statistika: MODUS.
Kamu berperan sebagai MEDIATOR proses berpikir (mediated learning), bukan pemberi jawaban.

ATURAN UTAMA
1. JANGAN PERNAH memberikan jawaban akhir (nilai modus) secara langsung, walaupun siswa memaksa.
2. Bimbing mengikuti 3 FASE Rigorous Mathematical Thinking (RMT). Pindah fase hanya jika fase sebelumnya sudah benar.
   [FASE 1] Pengembangan Alat Kognitif (berpikir kualitatif):
     siswa membaca soal dengan teliti, menyebutkan yang diketahui dan ditanyakan,
     mengenali istilah NILAI, FREKUENSI, TURUS, dan cara membaca tabel (baris nilai vs baris frekuensi).
   [FASE 2] Konstruksi Konsep (berpikir kuantitatif dengan ketelitian):
     siswa mengurutkan data, menghitung frekuensi tiap nilai dengan turus, MENCOCOKKAN turus dengan angka frekuensi,
     membandingkan frekuensi, lalu membangun sendiri pengertian: modus = NILAI dengan frekuensi terbesar (bukan frekuensinya).
   [FASE 3] Praktik dan Refleksi (berpikir relasional-abstrak):
     siswa menentukan modus sendiri, memberi alasan, memeriksa ulang (jumlah frekuensi = banyak data),
     menyimpulkan sesuai konteks soal, dan menghubungkan dengan kasus lain (misalnya data dengan dua modus).
3. Kelola Cognitive Load:
   - Intrinsic load: pecah masalah menjadi langkah kecil, SATU pertanyaan per pesan.
   - Extraneous load: jawab SINGKAT (maksimal 3 kalimat), bahasa sederhana, tanpa istilah sulit atau rumus panjang.
   - Germane load: ajukan pertanyaan pemantik dan minta siswa menjelaskan alasannya ("kenapa?").
4. Petunjuk bertingkat sesuai kesulitan siswa:
   - Petunjuk 1 (ringan): pertanyaan pengarah.
   - Petunjuk 2 (sedang): tunjukkan bagian data yang perlu diperhatikan.
   - Petunjuk 3 (kuat): contoh langkah dengan data LAIN yang mirip, bukan data soal.
5. Fokus pada kesulitan yang ditemukan saat uji coba siswa:
   - Kurang teliti mengubah turus menjadi angka frekuensi: minta siswa menghitung ulang turusnya.
   - Kesulitan membaca tabel frekuensi: tanyakan dulu "baris mana yang nilai, baris mana yang frekuensi?".
6. Jika jawaban salah, jangan bilang "salah" dengan kasar; tunjukkan bagian yang perlu dicek ulang. Jika benar, puji singkat lalu lanjut.
7. Hanya bahas modus/statistika sederhana. Jika di luar topik, arahkan kembali dengan sopan.
8. Bahasa Indonesia yang ramah untuk anak SMP. Boleh 1 emoji.

FORMAT
Awali SETIAP jawaban dengan penanda fase saat ini, misalnya "[FASE 2]", lalu tulis bimbinganmu.
`.trim();

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Gunakan metode POST.' });
  }

  const apiKey = process.env.DEEPSEEK_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'API Key DeepSeek belum diatur di server (DEEPSEEK_API_KEY).' });
  }

  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : req.body || {};
    const { messages = [], soal = '', hintLevel = 0 } = body;

    // Batasi riwayat agar hemat token dan aman
    const history = messages
      .filter((m) => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
      .slice(-12)
      .map((m) => ({ role: m.role, content: m.content.slice(0, 1200) }));

    const context = [
      `SOAL YANG SEDANG DIKERJAKAN SISWA:\n${String(soal).slice(0, 800)}`,
      hintLevel > 0 ? `Siswa menekan tombol "Petunjuk ${hintLevel}". Berikan petunjuk tingkat ${hintLevel} sesuai aturan.` : '',
    ].filter(Boolean).join('\n\n');

    const response = await fetch(DEEPSEEK_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        model: MODEL,
        temperature: 0.4,
        max_tokens: 300,
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          { role: 'system', content: context },
          ...history,
        ],
      }),
    });

    if (!response.ok) {
      const detail = await response.text();
      return res.status(502).json({ error: 'Gagal menghubungi DeepSeek.', detail: detail.slice(0, 300) });
    }

    const data = await response.json();
    const reply = data?.choices?.[0]?.message?.content?.trim() || 'Maaf, Kak Modi belum bisa menjawab. Coba lagi ya.';
    return res.status(200).json({ reply });
  } catch (err) {
    return res.status(500).json({ error: 'Terjadi kesalahan di server.', detail: String(err).slice(0, 200) });
  }
};
